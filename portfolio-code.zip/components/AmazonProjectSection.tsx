"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import LogoBadge from "@/components/LogoBadge";
import useParallax from "@/app/hooks/useParallax";
import { fadeInFromLeft, fadeInFromRight, staggerContainer } from "@/app/utils/animationVariants";

export default function AmazonProjectSection() {
  const { ref } = useParallax();

  return (
    <section className="relative w-full py-16 md:py-24" ref={ref}>
      
      {/* 1. HEADER ROW */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-16 md:mb-24 flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 border-b border-white/10 pb-6"
      >
        <LogoBadge 
          logoSrc="/assets/amazon-logo.png" 
          alt="Amazon" 
          className="w-20 md:w-24 h-auto opacity-100 brightness-0 invert" 
        />
        <div className="hidden sm:block h-6 w-[1px] bg-white/20"></div>
        <span className="text-xs md:text-sm font-mono text-zinc-400 uppercase tracking-widest">Lead Researcher, Devices Design Group</span>
      </motion.div>

      {/* 2. MAIN CONTENT STACK */}
      <div className="space-y-32 md:space-y-48">
        
        {/* === ROW 1: THE $1.7B STRATEGY (Structured Card Layout) === */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start"
        >
          
          {/* LEFT COLUMN: THE NARRATIVE (Span 7/12) */}
          <motion.div 
            variants={fadeInFromLeft} 
            className="lg:col-span-7 flex flex-col order-2 lg:order-1 relative"
          >
            {/* Headline Group */}
            <div className="mb-10">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">
                Calibrating the <br /> Revenue Model
              </h3>
              
              <div className="flex flex-col items-start">
                <div className="text-6xl md:text-8xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-zinc-500 tracking-tighter">
                  $1.7B
                </div>
                <div className="inline-flex items-center gap-2 mt-2 border-l-2 border-cyan-500 pl-3">
                   <span className="text-sm text-zinc-400 font-mono uppercase tracking-widest">
                    Incremental Revenue <br className="md:hidden"/> (15-mo Forecast)
                   </span>
                </div>
              </div>
            </div>

            {/* STRUCTURED TIMELINE CARDS */}
            <div className="relative space-y-6">
              {/* Connector Line */}
              <div className="absolute left-[19px] top-6 bottom-6 w-[2px] bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500 opacity-30"></div>

              {/* PHASE 1 CARD */}
              <div className="relative pl-12">
                <span className="absolute left-[11px] top-6 w-4 h-4 rounded-full bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.6)] border-2 border-black z-10"></span>
                <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-colors">
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-2">
                    Phase 1: Psychophysics
                  </h4>
                  <p className="text-base text-zinc-300 leading-relaxed">
                    Engineering targets were arbitrary. I led a controlled lab study (n=30) manipulating Alexa latency. We discovered a <span className="text-white font-semibold">"Cliff of Dissatisfaction" at 1000ms</span>—the biological threshold where delight collapses.
                  </p>
                </div>
              </div>

              {/* PHASE 2 CARD */}
              <div className="relative pl-12">
                <span className="absolute left-[11px] top-6 w-4 h-4 rounded-full bg-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.6)] border-2 border-black z-10"></span>
                <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-colors">
                  <h4 className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">
                    Phase 2: Model Calibration
                  </h4>
                  <p className="text-base text-zinc-300 leading-relaxed">
                    Finance's NVA (Negative Value Action) model lacked inputs for human frustration. I worked with Economics to ingest my 1000ms threshold, redefining "Defects" as <span className="text-white font-semibold">any interaction slower than human perception.</span>
                  </p>
                </div>
              </div>

              {/* PHASE 3 CARD */}
              <div className="relative pl-12">
                <span className="absolute left-[11px] top-6 w-4 h-4 rounded-full bg-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.6)] border-2 border-black z-10"></span>
                <div className="p-6 rounded-2xl bg-gradient-to-r from-pink-900/20 to-purple-900/20 border border-pink-500/20 hover:border-pink-500/40 transition-colors">
                  <h4 className="text-xs font-bold text-pink-400 uppercase tracking-widest mb-2">
                    Phase 3: The Projection
                  </h4>
                  <p className="text-base text-zinc-200 leading-relaxed">
                    The recalibrated model proved that meeting biological thresholds for high-priority intents (Music, Home) would save <span className="text-white font-bold">50.3B dialogs</span> and unlock <span className="text-green-400 font-bold">$1.7B</span> in incremental OPS.
                  </p>
                </div>
              </div>

            </div>
          </motion.div>

          {/* RIGHT COLUMN: THE CHART (Span 5/12) */}
          <motion.div 
            variants={fadeInFromRight} 
            className="lg:col-span-5 order-1 lg:order-2 lg:sticky lg:top-32"
          >
            <div className="relative group rounded-2xl overflow-hidden border border-white/10 bg-zinc-900/50 backdrop-blur-sm shadow-2xl">
               {/* Ambient Glow */}
               <div className="absolute -inset-1 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 opacity-30 blur-2xl group-hover:opacity-50 transition duration-1000"></div>
               
               <Image
                src="/assets/economic_threshold_model.png"
                alt="Psychophysical Latency Thresholds & Revenue Impact"
                width={800}
                height={600}
                className="relative z-10 object-cover w-full h-auto select-none" 
              />
              
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent z-20">
                <div className="flex justify-between items-end text-[10px] font-mono text-zinc-500 uppercase tracking-wider">
                  <span>Fig 1. The Psychophysical "Cliff"</span>
                  <span className="text-right opacity-60">Source: Internal NVA Model</span>
                </div>
              </div>
            </div>
          </motion.div>

        </motion.div>


        {/* === ROW 2: NEUROSCIENCE (Competitive Benchmark) === */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center"
        >
          <motion.div variants={fadeInFromLeft} className="relative group w-full">
            <div className="absolute -inset-2 bg-gradient-to-bl from-blue-600/20 to-purple-600/20 rounded-3xl blur-2xl opacity-20 group-hover:opacity-40 transition duration-1000"></div>
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-black">
              <video
                src="/assets/fnirs.mp4"
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-auto aspect-video object-cover opacity-90 group-hover:opacity-100 transition-opacity"
              />
            </div>
            <span className="block mt-4 text-center text-xs font-mono text-zinc-500 uppercase tracking-wider">
              Settling Design Debates with fNIRS Data
            </span>
          </motion.div>

          <motion.div variants={fadeInFromRight} className="flex flex-col justify-center">
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-8 leading-tight">
              Competitive Biological <br/> Benchmarking
            </h3>
            
            <div className="space-y-8">
              <p className="text-lg text-zinc-300 leading-relaxed">
                Stakeholders debated whether "richness" (density) or "minimalism" drove engagement. I used fNIRS to benchmark FireTV against Apple TV, proving that high visual density triggered significantly higher activation in the Left DLPFC—<span className="text-white font-semibold">physically fatiguing the user</span> before they even selected content.
              </p>
              
              <ul className="space-y-4">
                 <li className="flex gap-4">
                   <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-white mt-2.5"></span>
                   <p className="text-zinc-400 leading-relaxed">
                     <strong className="text-zinc-200 block mb-1">Operationalizing "Clutter"</strong>
                     Converted the vague aesthetic concept of "clutter" into a quantifiable biological metric (DLPFC Activation).
                   </p>
                 </li>
                 <li className="flex gap-4">
                   <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-white mt-2.5"></span>
                   <p className="text-zinc-400 leading-relaxed">
                     <strong className="text-zinc-200 block mb-1">Strategic Impact</strong>
                     Mandated a UI overhaul to separate Apps from Video Content, proving that reducing density was not just an aesthetic choice, but a biological requirement for retention.
                   </p>
                 </li>
              </ul>
            </div>
          </motion.div>
        </motion.div>


        {/* === ROW 3: HARDWARE (Floating Echo) === */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center"
        >
          <motion.div variants={fadeInFromLeft} className="flex flex-col justify-center order-2 lg:order-1">
             <h3 className="text-3xl md:text-4xl font-bold text-white mb-6 leading-tight">
              Multimodal AI + Hardware
             </h3>
             
             <div className="space-y-6 mb-8">
               <p className="text-lg text-zinc-300 leading-relaxed">
                 Led end-to-end Human Factors strategy for high-visibility consumer AI hardware (Echo Show), shaping product requirements for the Alexa+ ecosystem serving <span className="text-white font-bold">75M+ customers</span>.
               </p>
             </div>

             <div className="inline-flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-yellow-500/10 to-transparent rounded-full border border-yellow-500/20 w-fit group hover:border-yellow-500/40 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500 group-hover:scale-110 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1.323l3.954 1.582 1.699-3.181a1 1 0 011.827.954L17.5 7.677V13a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2.5l-2.481-.992-.472 2.361c-.13.65-.694 1.131-1.358 1.131H5.452c-.664 0-1.229-.481-1.358-1.131L3.622 9.508l-2.481.992V13a1 1 0 01-1 1h-2a1 1 0 01-1-1V7.677l-.98-3.92a1 1 0 011.827-.954L1.046 5.905 5 4.323V3a1 1 0 011-1h4z" clipRule="evenodd" />
                  <path d="M10 18a2 2 0 100-4 2 2 0 000 4z" />
                </svg>
                <span className="text-xs font-bold text-yellow-500 uppercase tracking-widest">Amazon Inventor Award Recipient</span>
             </div>
          </motion.div>

          {/* Asset Block: FLOATING ECHO SHOW */}
          <motion.div 
            variants={fadeInFromRight} 
            className="relative w-full order-1 lg:order-2 flex flex-col items-center"
          >
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ 
                duration: 6, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
              className="relative w-full max-w-sm mx-auto"
            >
              {/* Blue Backlight Glow */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] bg-blue-500/10 blur-[60px] rounded-full -z-10"></div>
              
              <Image
                src="/assets/echo.png"
                alt="Echo Show 10 Motion-Tracking"
                width={800}
                height={500}
                className="relative z-10 w-full h-auto drop-shadow-2xl select-none hover:scale-105 transition-transform duration-500" 
              />
            </motion.div>
            
            <span className="block mt-8 text-center text-xs font-mono text-zinc-500 uppercase tracking-wider">
              Led end-to-end research for Echo Show 10 w/ motion-tracking
            </span>
          </motion.div>
        </motion.div>

      </div>
    </section>
  );
}